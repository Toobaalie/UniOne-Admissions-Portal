# UniOne Roadmap

## Architecture
- Frontend + server: TanStack Start (React 19, Tailwind v4), server functions for APIs
- Backend: Lovable Cloud (Postgres, auth: email/password, phone OTP, Google; private storage with signed URLs)
- Payments: `PaymentGateway` interface (mock now; JazzCash, Easypaisa, Stripe, bank transfer adapters later)
- i18n: all copy kept structured for Urdu (RTL) later

```text
src/
  routes/            public pages, /_authenticated/student|uni|admin areas
  components/site/   header, footer, cards
  lib/data/          seed data (moves to DB in Phase 2)
  lib/payments/      gateway abstraction (Phase 3)
```

## Phase 1 (done)
- [x] Design system, header/footer
- [x] Landing, About, Contact, Privacy, Terms
- [x] Universities directory with filters, detail pages, shortlist + compare (local)
- [x] Seed data: 10 universities with programs

## Next
- [ ] Phase 2: enable Cloud, schema (users, student_profiles, education_records, test_scores, documents, universities, programs, custom_fields, applications, application_answers, application_documents, payments, payment_items, notifications, shortlists, audit_logs), auth, master profile, document vault
- [ ] Phase 3: multi-application flow, cart + mock checkout, receipts, tracking dashboard, notifications
- [ ] Phase 4: university portal (programs, form builder, review, bulk status, analytics, CSV)
- [ ] Phase 5: super admin (onboarding, commissions, settlements, CMS, duplicates, audit logs)
