export type Program = {
  id: string;
  name: string;
  level: "Bachelor" | "Master" | "PhD";
  field: string;
  fee: number; // application fee PKR
  tuition: number; // per year PKR
  seats: number;
  deadline: string; // ISO
  requirements: string;
};

export type University = {
  slug: string;
  name: string;
  short: string;
  city: string;
  type: "Public" | "Private";
  founded: number;
  scholarships: boolean;
  about: string;
  email: string;
  phone: string;
  website: string;
  programs: Program[];
};

const p = (
  id: string,
  name: string,
  level: Program["level"],
  field: string,
  fee: number,
  tuition: number,
  seats: number,
  deadline: string,
  requirements: string,
): Program => ({ id, name, level, field, fee, tuition, seats, deadline, requirements });

export const universities: University[] = [
  {
    slug: "lums", name: "Lahore University of Management Sciences", short: "LUMS", city: "Lahore", type: "Private", founded: 1984, scholarships: true,
    about: "A leading research university known for business, computer science and the humanities, with a generous need-based financial aid programme.",
    email: "admissions@lums.edu.pk", phone: "+92 42 3560 8000", website: "lums.edu.pk",
    programs: [
      p("lums-cs", "BS Computer Science", "Bachelor", "Computer Science", 6500, 1100000, 250, "2026-12-15", "Intermediate 70%+, SAT or LCAT"),
      p("lums-bba", "BSc Management Science", "Bachelor", "Business", 6500, 1050000, 300, "2026-12-15", "Intermediate 65%+, SAT or LCAT"),
      p("lums-mba", "MBA", "Master", "Business", 8000, 1400000, 150, "2027-01-20", "Bachelor's 16 years, GMAT/LGAT"),
    ],
  },
  {
    slug: "nust", name: "National University of Sciences & Technology", short: "NUST", city: "Islamabad", type: "Public", founded: 1991, scholarships: true,
    about: "Pakistan's top-ranked engineering and technology university with campuses across the country.",
    email: "ugadmissions@nust.edu.pk", phone: "+92 51 9085 6878", website: "nust.edu.pk",
    programs: [
      p("nust-ee", "BE Electrical Engineering", "Bachelor", "Engineering", 4000, 380000, 400, "2026-11-30", "FSc Pre-Engineering 60%+, NET"),
      p("nust-se", "BS Software Engineering", "Bachelor", "Computer Science", 4000, 380000, 200, "2026-11-30", "FSc 60%+, NET"),
      p("nust-ms-ai", "MS Artificial Intelligence", "Master", "Computer Science", 5000, 300000, 60, "2027-02-10", "BS CS/EE, GAT General 50+"),
    ],
  },
  {
    slug: "iba", name: "Institute of Business Administration", short: "IBA Karachi", city: "Karachi", type: "Public", founded: 1955, scholarships: true,
    about: "The oldest business school outside North America, renowned for business, economics and computer science.",
    email: "admissions@iba.edu.pk", phone: "+92 21 3810 4700", website: "iba.edu.pk",
    programs: [
      p("iba-bba", "BBA", "Bachelor", "Business", 5000, 900000, 350, "2026-12-05", "Intermediate 60%+, IBA test"),
      p("iba-econ", "BS Economics", "Bachelor", "Social Sciences", 5000, 900000, 120, "2026-12-05", "Intermediate 60%+, IBA test"),
    ],
  },
  {
    slug: "aku", name: "Aga Khan University", short: "AKU", city: "Karachi", type: "Private", founded: 1983, scholarships: true,
    about: "An internationally recognised university for medicine, nursing and education.",
    email: "admissions@aku.edu", phone: "+92 21 3486 4949", website: "aku.edu",
    programs: [
      p("aku-mbbs", "MBBS", "Bachelor", "Medicine", 10000, 2600000, 100, "2026-11-20", "FSc Pre-Medical 70%+, AKU test"),
      p("aku-bscn", "BSc Nursing", "Bachelor", "Medicine", 6000, 900000, 120, "2026-12-20", "FSc Pre-Medical 60%+"),
    ],
  },
  {
    slug: "comsats", name: "COMSATS University Islamabad", short: "COMSATS", city: "Islamabad", type: "Public", founded: 1998, scholarships: true,
    about: "A large public university with strong programmes in IT, engineering and management sciences.",
    email: "admissions@comsats.edu.pk", phone: "+92 51 9049 5000", website: "comsats.edu.pk",
    programs: [
      p("cui-cs", "BS Computer Science", "Bachelor", "Computer Science", 2500, 260000, 500, "2027-01-15", "Intermediate 50%+, NTS NAT"),
      p("cui-bba", "BBA", "Bachelor", "Business", 2500, 240000, 300, "2027-01-15", "Intermediate 45%+, NTS NAT"),
    ],
  },
  {
    slug: "fast", name: "FAST National University", short: "FAST-NUCES", city: "Lahore", type: "Private", founded: 2000, scholarships: true,
    about: "A computing-focused university with campuses in Lahore, Karachi, Islamabad, Peshawar and Faisalabad.",
    email: "admissions@nu.edu.pk", phone: "+92 42 111 128 128", website: "nu.edu.pk",
    programs: [
      p("fast-cs", "BS Computer Science", "Bachelor", "Computer Science", 3000, 420000, 600, "2026-12-25", "Intermediate 60%+, NU test"),
      p("fast-ds", "BS Data Science", "Bachelor", "Computer Science", 3000, 420000, 150, "2026-12-25", "Intermediate 60%+, NU test"),
    ],
  },
  {
    slug: "uet", name: "University of Engineering & Technology", short: "UET Lahore", city: "Lahore", type: "Public", founded: 1921, scholarships: false,
    about: "One of the oldest engineering institutions in South Asia with a century of excellence.",
    email: "admissions@uet.edu.pk", phone: "+92 42 9902 9254", website: "uet.edu.pk",
    programs: [
      p("uet-me", "BSc Mechanical Engineering", "Bachelor", "Engineering", 2000, 150000, 300, "2026-11-25", "FSc Pre-Engineering 60%+, ECAT"),
      p("uet-ce", "BSc Civil Engineering", "Bachelor", "Engineering", 2000, 150000, 300, "2026-11-25", "FSc Pre-Engineering 60%+, ECAT"),
    ],
  },
  {
    slug: "qau", name: "Quaid-i-Azam University", short: "QAU", city: "Islamabad", type: "Public", founded: 1967, scholarships: true,
    about: "A research university known for natural sciences, social sciences and graduate studies.",
    email: "admissions@qau.edu.pk", phone: "+92 51 9064 0000", website: "qau.edu.pk",
    programs: [
      p("qau-phy", "BS Physics", "Bachelor", "Sciences", 1500, 90000, 80, "2027-01-30", "FSc 50%+"),
      p("qau-mphil", "MPhil Economics", "Master", "Social Sciences", 2000, 110000, 40, "2027-02-15", "16 years education, GAT"),
      p("qau-phd", "PhD Chemistry", "PhD", "Sciences", 3000, 130000, 15, "2027-03-01", "MPhil, GAT Subject"),
    ],
  },
  {
    slug: "kemu", name: "King Edward Medical University", short: "KEMU", city: "Lahore", type: "Public", founded: 1860, scholarships: false,
    about: "Pakistan's oldest medical institution, a centre of excellence for clinical training.",
    email: "admissions@kemu.edu.pk", phone: "+92 42 9921 1145", website: "kemu.edu.pk",
    programs: [p("kemu-mbbs", "MBBS", "Bachelor", "Medicine", 3000, 50000, 350, "2026-11-28", "FSc Pre-Medical 60%+, MDCAT")],
  },
  {
    slug: "uop", name: "University of Peshawar", short: "UoP", city: "Peshawar", type: "Public", founded: 1950, scholarships: true,
    about: "The leading university of Khyber Pakhtunkhwa, offering a wide range of arts, science and law programmes.",
    email: "admissions@uop.edu.pk", phone: "+92 91 921 6701", website: "uop.edu.pk",
    programs: [
      p("uop-llb", "LLB (5 years)", "Bachelor", "Law", 1500, 80000, 120, "2027-01-10", "Intermediate 45%+, LAT"),
      p("uop-eng", "BS English", "Bachelor", "Social Sciences", 1500, 70000, 100, "2027-01-10", "Intermediate 45%+"),
    ],
  },
];

export const cities = [...new Set(universities.map((u) => u.city))].sort();
export const fields = [...new Set(universities.flatMap((u) => u.programs.map((p) => p.field)))].sort();

export const formatPKR = (n: number) => "Rs " + n.toLocaleString("en-PK");
export const formatDate = (d: string) =>
  new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
export const minFee = (u: University) => Math.min(...u.programs.map((p) => p.fee));
export const nextDeadline = (u: University): string => u.programs.map((p) => p.deadline).sort()[0] ?? "";
export const getUniversity = (slug: string) => universities.find((u) => u.slug === slug);
