import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SearchX } from "lucide-react";
import { universities, cities, fields, minFee, nextDeadline } from "@/lib/data/universities";
import { UniversityCard } from "@/components/site/UniversityCard";
import { PageHeader } from "@/components/site/Layout";

export const Route = createFileRoute("/universities/")({
  head: () => ({
    meta: [
      { title: "Universities in Pakistan — UniOne" },
      { name: "description", content: "Search and filter Pakistani universities by city, degree, field, fee, deadline and scholarships." },
      { property: "og:title", content: "Universities in Pakistan — UniOne" },
      { property: "og:description", content: "Browse and compare universities and programs across Pakistan." },
    ],
  }),
  component: Directory,
});

function Directory() {
  const [q, setQ] = useState("");
  const [city, setCity] = useState("");
  const [level, setLevel] = useState("");
  const [field, setField] = useState("");
  const [maxFee, setMaxFee] = useState(10000);
  const [before, setBefore] = useState("");
  const [schol, setSchol] = useState(false);

  const results = useMemo(
    () =>
      universities.filter((u) => {
        if (q && !`${u.name} ${u.short} ${u.programs.map((p) => p.name).join(" ")}`.toLowerCase().includes(q.toLowerCase())) return false;
        if (city && u.city !== city) return false;
        if (level && !u.programs.some((p) => p.level === level)) return false;
        if (field && !u.programs.some((p) => p.field === field)) return false;
        if (minFee(u) > maxFee) return false;
        if (before && nextDeadline(u) > before) return false;
        if (schol && !u.scholarships) return false;
        return true;
      }),
    [q, city, level, field, maxFee, before, schol],
  );

  const reset = () => { setQ(""); setCity(""); setLevel(""); setField(""); setMaxFee(10000); setBefore(""); setSchol(false); };

  return (
    <>
      <PageHeader eyebrow="Discover" title="Find your university">Search {universities.length} universities and filter by what matters to you.</PageHeader>
      <div className="container-page grid gap-8 py-10 lg:grid-cols-[17rem_1fr]">
        <aside className="h-fit space-y-4 rounded-2xl border bg-card p-5 shadow-card lg:sticky lg:top-20" aria-label="Filters">
          <label className="block text-sm font-semibold">Search
            <input className="input-field mt-1" value={q} onChange={(e) => setQ(e.target.value)} placeholder="University or program" />
          </label>
          <label className="block text-sm font-semibold">City
            <select className="input-field mt-1" value={city} onChange={(e) => setCity(e.target.value)}>
              <option value="">All cities</option>{cities.map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
          <label className="block text-sm font-semibold">Degree level
            <select className="input-field mt-1" value={level} onChange={(e) => setLevel(e.target.value)}>
              <option value="">Any</option><option>Bachelor</option><option>Master</option><option>PhD</option>
            </select>
          </label>
          <label className="block text-sm font-semibold">Field
            <select className="input-field mt-1" value={field} onChange={(e) => setField(e.target.value)}>
              <option value="">All fields</option>{fields.map((f) => <option key={f}>{f}</option>)}
            </select>
          </label>
          <label className="block text-sm font-semibold">Max application fee: Rs {maxFee.toLocaleString()}
            <input type="range" min={1000} max={10000} step={500} value={maxFee} onChange={(e) => setMaxFee(+e.target.value)} className="mt-2 w-full accent-primary" />
          </label>
          <label className="block text-sm font-semibold">Deadline before
            <input type="date" className="input-field mt-1" value={before} onChange={(e) => setBefore(e.target.value)} />
          </label>
          <label className="flex items-center gap-2 text-sm font-semibold">
            <input type="checkbox" checked={schol} onChange={(e) => setSchol(e.target.checked)} className="accent-primary" /> Offers scholarships
          </label>
          <button onClick={reset} className="btn btn-ghost w-full">Reset filters</button>
        </aside>
        <section aria-live="polite">
          <p className="mb-4 text-sm text-muted-foreground">{results.length} universities found</p>
          {results.length === 0 ? (
            <div className="rounded-2xl border border-dashed p-12 text-center">
              <SearchX className="mx-auto h-10 w-10 text-muted-foreground" />
              <h2 className="mt-3 font-bold">No universities match</h2>
              <p className="text-sm text-muted-foreground">Try widening your filters.</p>
              <button onClick={reset} className="btn btn-primary mt-4">Clear filters</button>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">{results.map((u) => <UniversityCard key={u.slug} u={u} />)}</div>
          )}
        </section>
      </div>
    </>
  );
}
