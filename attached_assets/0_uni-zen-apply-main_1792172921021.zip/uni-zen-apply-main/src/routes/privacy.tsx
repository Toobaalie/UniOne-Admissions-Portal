import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/Layout";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — UniOne" },
      { name: "description", content: "How UniOne collects, stores and protects your personal data and documents." },
      { property: "og:title", content: "Privacy Policy — UniOne" },
      { property: "og:description", content: "How UniOne protects your data." },
    ],
  }),
  component: () => (
    <>
      <PageHeader title="Privacy Policy">Last updated October 2026</PageHeader>
      <div className="container-page max-w-3xl space-y-6 py-12 text-muted-foreground">
        {[
          ["What we collect", "Profile details, academic records, test scores and documents you choose to upload."],
          ["How we use it", "Only to process applications you submit, to universities you select."],
          ["Documents", "Stored privately and shared through time-limited secure links. Universities see only what you apply with."],
          ["Payments", "We never store card details. Payments are processed by licensed payment partners."],
          ["Your rights", "You can download or delete your data at any time by contacting support."],
        ].map(([h, t]) => (
          <section key={h}><h2 className="text-lg font-bold text-foreground">{h}</h2><p className="mt-1">{t}</p></section>
        ))}
      </div>
    </>
  ),
});
