import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Heart, Mail, Phone, Globe, MapPin, Award, CalendarClock } from "lucide-react";
import { getUniversity, formatDate, formatPKR } from "@/lib/data/universities";
import { useShortlist } from "@/lib/shortlist";

export const Route = createFileRoute("/universities/$slug")({
  loader: ({ params }) => {
    const u = getUniversity(params.slug);
    if (!u) throw notFound();
    return u;
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.name} — Admissions on UniOne` },
          { name: "description", content: `${loaderData.short} programs, fees, requirements and deadlines. Apply through UniOne.` },
          { property: "og:title", content: `${loaderData.name} — UniOne` },
          { property: "og:description", content: loaderData.about },
        ]
      : [{ title: "University not found — UniOne" }, { name: "robots", content: "noindex" }],
  }),
  notFoundComponent: () => (
    <div className="container-page py-24 text-center">
      <h1 className="text-2xl font-bold">University not found</h1>
      <Link to="/universities" className="btn btn-primary mt-6">Back to directory</Link>
    </div>
  ),
  component: Detail,
});

function Detail() {
  const u = Route.useLoaderData();
  const { has, toggle } = useShortlist();
  const saved = has(u.slug);
  return (
    <>
      <section className="border-b bg-secondary/60">
        <div className="container-page flex flex-col gap-6 py-12 md:flex-row md:items-end md:justify-between">
          <div>
            <Link to="/universities" className="text-sm font-semibold text-muted-foreground hover:text-primary">← All universities</Link>
            <h1 className="mt-3 text-3xl font-bold text-primary md:text-5xl">{u.name}</h1>
            <div className="mt-3 flex flex-wrap gap-4 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1"><MapPin className="h-4 w-4" />{u.city}</span>
              <span>{u.type} · Est. {u.founded}</span>
              {u.scholarships && <span className="inline-flex items-center gap-1 text-success"><Award className="h-4 w-4" />Scholarships available</span>}
            </div>
          </div>
          <button onClick={() => toggle(u.slug)} className={saved ? "btn btn-warm" : "btn btn-ghost"} aria-pressed={saved}>
            <Heart className="h-4 w-4" fill={saved ? "currentColor" : "none"} /> {saved ? "Shortlisted" : "Add to shortlist"}
          </button>
        </div>
      </section>
      <div className="container-page grid gap-10 py-12 lg:grid-cols-[1fr_20rem]">
        <div>
          <h2 className="text-xl font-bold">About</h2>
          <p className="mt-2 text-muted-foreground">{u.about}</p>
          <h2 className="mt-10 text-xl font-bold">Programs, fees & requirements</h2>
          <div className="mt-4 space-y-4">
            {u.programs.map((p) => (
              <article key={p.id} className="rounded-2xl border bg-card p-5 shadow-card">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold">{p.name}</h3>
                    <div className="text-sm text-muted-foreground">{p.level} · {p.field} · {p.seats} seats</div>
                  </div>
                  <span className="inline-flex items-center gap-1 rounded-full bg-warm-soft px-3 py-1 text-xs font-bold text-warm-foreground">
                    <CalendarClock className="h-3.5 w-3.5" /> Deadline {formatDate(p.deadline)}
                  </span>
                </div>
                <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-3">
                  <div><dt className="text-muted-foreground">Application fee</dt><dd className="font-bold text-primary">{formatPKR(p.fee)}</dd></div>
                  <div><dt className="text-muted-foreground">Tuition / year</dt><dd className="font-bold">{formatPKR(p.tuition)}</dd></div>
                  <div><dt className="text-muted-foreground">Requirements</dt><dd className="font-semibold">{p.requirements}</dd></div>
                </dl>
              </article>
            ))}
          </div>
        </div>
        <aside className="h-fit space-y-3 rounded-2xl border bg-card p-6 shadow-card lg:sticky lg:top-20">
          <h2 className="font-bold">Contact admissions</h2>
          <a href={`mailto:${u.email}`} className="flex items-center gap-2 text-sm hover:text-primary"><Mail className="h-4 w-4 text-warm" />{u.email}</a>
          <a href={`tel:${u.phone}`} className="flex items-center gap-2 text-sm hover:text-primary"><Phone className="h-4 w-4 text-warm" />{u.phone}</a>
          <div className="flex items-center gap-2 text-sm"><Globe className="h-4 w-4 text-warm" />{u.website}</div>
          <p className="border-t pt-4 text-xs text-muted-foreground">Online applications through UniOne open in the next release. Shortlist now to apply quickly.</p>
        </aside>
      </div>
    </>
  );
}
