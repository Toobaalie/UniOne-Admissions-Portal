import { createFileRoute, Link } from "@tanstack/react-router";
import { Heart, X } from "lucide-react";
import { universities, formatPKR, formatDate, minFee, nextDeadline } from "@/lib/data/universities";
import { useShortlist } from "@/lib/shortlist";
import { PageHeader } from "@/components/site/Layout";

export const Route = createFileRoute("/compare")({
  head: () => ({
    meta: [
      { title: "Shortlist & compare universities — UniOne" },
      { name: "description", content: "Compare your shortlisted universities side by side: fees, deadlines, programs and scholarships." },
      { property: "og:title", content: "Compare universities — UniOne" },
      { property: "og:description", content: "Side-by-side comparison of your shortlisted universities." },
    ],
  }),
  component: Compare,
});

function Compare() {
  const { items, toggle } = useShortlist();
  const list = universities.filter((u) => items.includes(u.slug));
  const rows: [string, (u: (typeof list)[number]) => React.ReactNode][] = [
    ["City", (u) => u.city],
    ["Type", (u) => u.type],
    ["Founded", (u) => u.founded],
    ["Programs", (u) => u.programs.map((p) => p.name).join(", ")],
    ["Application fee from", (u) => formatPKR(minFee(u))],
    ["Next deadline", (u) => formatDate(nextDeadline(u))],
    ["Scholarships", (u) => (u.scholarships ? "Yes" : "No")],
  ];
  return (
    <>
      <PageHeader eyebrow="Shortlist" title="Compare side by side">Add universities with the heart icon to compare them here.</PageHeader>
      <div className="container-page py-10">
        {list.length === 0 ? (
          <div className="rounded-2xl border border-dashed p-12 text-center">
            <Heart className="mx-auto h-10 w-10 text-warm" />
            <h2 className="mt-3 font-bold">Your shortlist is empty</h2>
            <p className="text-sm text-muted-foreground">Browse universities and tap the heart to save them.</p>
            <Link to="/universities" className="btn btn-primary mt-4">Browse universities</Link>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-2xl border bg-card shadow-card">
            <table className="w-full min-w-[40rem] text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-4 text-left text-muted-foreground">Criteria</th>
                  {list.map((u) => (
                    <th key={u.slug} className="p-4 text-left align-top">
                      <div className="flex items-start justify-between gap-2">
                        <Link to="/universities/$slug" params={{ slug: u.slug }} className="font-display font-bold text-primary hover:underline">{u.short}</Link>
                        <button onClick={() => toggle(u.slug)} aria-label={`Remove ${u.short}`} className="text-muted-foreground hover:text-destructive"><X className="h-4 w-4" /></button>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map(([label, fn]) => (
                  <tr key={label} className="border-b last:border-0">
                    <th className="p-4 text-left font-semibold text-muted-foreground">{label}</th>
                    {list.map((u) => <td key={u.slug} className="p-4">{fn(u)}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
