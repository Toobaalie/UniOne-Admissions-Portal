import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2, Mail, Phone } from "lucide-react";
import { PageHeader } from "@/components/site/Layout";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact UniOne — Student and university support" },
      { name: "description", content: "Get help with your applications or onboard your university on UniOne." },
      { property: "og:title", content: "Contact UniOne" },
      { property: "og:description", content: "Support for students and universities." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState("");
  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email") || "");
    if (String(f.get("name") || "").trim().length < 2) return setErr("Please enter your name.");
    if (!/^\S+@\S+\.\S+$/.test(email)) return setErr("Please enter a valid email.");
    if (String(f.get("message") || "").trim().length < 10) return setErr("Message should be at least 10 characters.");
    setErr("");
    setSent(true);
  };
  return (
    <>
      <PageHeader eyebrow="Contact" title="We're here to help">Students, parents and universities — reach out anytime.</PageHeader>
      <div className="container-page grid max-w-5xl gap-10 py-14 md:grid-cols-[1fr_18rem]">
        {sent ? (
          <div className="rounded-2xl border bg-card p-10 text-center shadow-card">
            <CheckCircle2 className="mx-auto h-12 w-12 text-success" />
            <h2 className="mt-3 text-xl font-bold">Message received</h2>
            <p className="text-sm text-muted-foreground">We'll reply within one working day.</p>
          </div>
        ) : (
          <form onSubmit={submit} noValidate className="space-y-4 rounded-2xl border bg-card p-6 shadow-card">
            <label className="block text-sm font-semibold">Full name<input name="name" maxLength={100} className="input-field mt-1" /></label>
            <label className="block text-sm font-semibold">Email<input name="email" type="email" maxLength={255} className="input-field mt-1" /></label>
            <label className="block text-sm font-semibold">I am a
              <select name="role" className="input-field mt-1"><option>Student</option><option>Parent</option><option>University</option></select>
            </label>
            <label className="block text-sm font-semibold">Message<textarea name="message" rows={5} maxLength={2000} className="input-field mt-1" /></label>
            {err && <p role="alert" className="text-sm font-semibold text-destructive">{err}</p>}
            <button className="btn btn-primary">Send message</button>
          </form>
        )}
        <aside className="space-y-4 text-sm">
          <div className="flex items-center gap-2"><Mail className="h-4 w-4 text-warm" />support@unione.pk</div>
          <div className="flex items-center gap-2"><Phone className="h-4 w-4 text-warm" />+92 300 0000000</div>
          <p className="text-muted-foreground">Mon–Sat, 9am–6pm PKT</p>
        </aside>
      </div>
    </>
  );
}
