import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/Layout";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About UniOne — Pakistan's centralized admission portal" },
      { name: "description", content: "Why we built UniOne: making university admissions in Pakistan simple, fair and affordable." },
      { property: "og:title", content: "About UniOne" },
      { property: "og:description", content: "Making university admissions in Pakistan simple, fair and affordable." },
    ],
  }),
  component: () => (
    <>
      <PageHeader eyebrow="About" title="Admissions, simplified">Every year, millions of Pakistani students fill the same forms again and again, queue at banks and track deadlines on paper. UniOne changes that.</PageHeader>
      <div className="container-page grid max-w-5xl gap-8 py-14 md:grid-cols-3">
        {[
          ["Our mission", "Give every student, from Gilgit to Gwadar, equal and easy access to higher education."],
          ["For universities", "A modern portal to manage programs, review applicants, verify documents and issue offers."],
          ["Our promise", "Transparent fees, secure data, and support in English — with Urdu coming soon."],
        ].map(([t, d]) => (
          <div key={t} className="rounded-2xl border bg-card p-6 shadow-card">
            <h2 className="text-lg font-bold text-primary">{t}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{d}</p>
          </div>
        ))}
      </div>
      <div className="text-center"><Link to="/universities" className="btn btn-warm">Explore universities</Link></div>
    </>
  ),
});
