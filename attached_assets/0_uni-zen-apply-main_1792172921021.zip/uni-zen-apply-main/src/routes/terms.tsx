import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/Layout";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Use — UniOne" },
      { name: "description", content: "Terms governing the use of UniOne by students and universities." },
      { property: "og:title", content: "Terms of Use — UniOne" },
      { property: "og:description", content: "Terms for students and universities using UniOne." },
    ],
  }),
  component: () => (
    <>
      <PageHeader title="Terms of Use">Last updated October 2026</PageHeader>
      <div className="container-page max-w-3xl space-y-6 py-12 text-muted-foreground">
        {[
          ["Accounts", "You must provide accurate information. One account per person; duplicate accounts may be suspended."],
          ["Applications", "Admission decisions are made solely by universities. UniOne does not guarantee admission."],
          ["Fees", "Application fees are set by universities. The UniOne service fee is shown before checkout. Refunds follow each university's policy."],
          ["Acceptable use", "No fraudulent documents, impersonation or misuse of the platform."],
        ].map(([h, t]) => (
          <section key={h}><h2 className="text-lg font-bold text-foreground">{h}</h2><p className="mt-1">{t}</p></section>
        ))}
      </div>
    </>
  ),
});
