import { createFileRoute, Link } from "@tanstack/react-router";
import { UserRound, Search, Send, CreditCard, ShieldCheck, Clock, FolderCheck, Bell, Quote, ArrowRight } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { universities } from "@/lib/data/universities";
import { UniversityCard } from "@/components/site/UniversityCard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "UniOne — One profile, every university in Pakistan" },
      { name: "description", content: "Fill your details once, apply to multiple Pakistani universities and pay all application fees in a single checkout." },
      { property: "og:title", content: "UniOne — One profile, every university in Pakistan" },
      { property: "og:description", content: "Apply to multiple Pakistani universities from one place with a single checkout." },
    ],
  }),
  component: Index,
});

const steps = [
  { icon: UserRound, title: "Build your profile", text: "Personal, academic and test details — entered only once." },
  { icon: Search, title: "Pick programs", text: "Search, shortlist and compare universities across Pakistan." },
  { icon: Send, title: "Apply in one flow", text: "Every application auto-fills from your master profile." },
  { icon: CreditCard, title: "Pay once", text: "All application fees in one secure checkout." },
];

const benefits = [
  { icon: Clock, title: "Save weeks of paperwork", text: "No more re-typing the same forms for every university." },
  { icon: FolderCheck, title: "One document vault", text: "Upload CNIC, transcripts and photos once; reuse everywhere." },
  { icon: Bell, title: "Never miss a deadline", text: "Deadline calendar plus alerts for every status change." },
  { icon: ShieldCheck, title: "Secure by design", text: "Encrypted documents and no card data stored, ever." },
];

const testimonials = [
  { name: "Ayesha K.", city: "Multan", text: "I applied to five universities in one evening. Paying all fees together was a huge relief for my parents." },
  { name: "Hamza R.", city: "Quetta", text: "The deadline calendar saved me — I'd have missed NUST otherwise." },
  { name: "Fatima S.", city: "Hyderabad", text: "Uploading my documents once and seeing them verified made everything feel less stressful." },
];

const faqs = [
  { q: "Is UniOne free for students?", a: "Creating a profile and browsing is free. You only pay each university's application fee plus a small service fee at checkout." },
  { q: "Which payment methods will be supported?", a: "JazzCash, Easypaisa, debit/credit cards and bank transfer." },
  { q: "Can I still add university-specific essays?", a: "Yes. Each university can ask its own questions, essays or SOPs, which you fill in during the application flow." },
  { q: "Are my documents safe?", a: "Documents are stored privately and only shared with the universities you apply to, through secure time-limited links." },
];

function Index() {
  const featured = universities.slice(0, 6);
  return (
    <>
      <section className="relative overflow-hidden">
        <img src={hero} alt="Students on a university campus in Pakistan" width={1600} height={1008} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-hero" />
        <div className="container-page relative py-24 md:py-36">
          <div className="max-w-2xl text-ink-foreground">
            <span className="inline-block rounded-full bg-warm px-3 py-1 text-xs font-bold text-warm-foreground">Admissions 2026–27 are open</span>
            <h1 className="mt-5 text-4xl font-extrabold leading-tight md:text-6xl">One profile.<br />Every university.</h1>
            <p className="mt-5 text-lg opacity-90">Fill your details once, apply to multiple universities across Pakistan, and pay every application fee in a single checkout.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/universities" className="btn btn-warm">Find your program <ArrowRight className="h-4 w-4" /></Link>
              <Link to="/about" className="btn border border-ink-foreground/40 text-ink-foreground hover:bg-ink-foreground/10">How it works</Link>
            </div>
            <div className="mt-10 flex gap-8 text-sm">
              <div><div className="font-display text-2xl font-bold">10+</div><div className="opacity-75">Universities</div></div>
              <div><div className="font-display text-2xl font-bold">{universities.reduce((n, u) => n + u.programs.length, 0)}</div><div className="opacity-75">Programs</div></div>
              <div><div className="font-display text-2xl font-bold">1</div><div className="opacity-75">Checkout</div></div>
            </div>
          </div>
        </div>
      </section>

      <section className="container-page py-20">
        <h2 className="text-center text-3xl font-bold text-primary md:text-4xl">How it works</h2>
        <ol className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <li key={s.title} className="relative rounded-2xl border bg-card p-6 shadow-card">
              <span className="absolute -top-3 left-6 rounded-full bg-warm px-2.5 py-0.5 text-xs font-bold text-warm-foreground">Step {i + 1}</span>
              <s.icon className="h-8 w-8 text-primary" />
              <h3 className="mt-4 font-bold">{s.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="bg-secondary/60 py-20">
        <div className="container-page grid gap-12 lg:grid-cols-2 lg:items-center">
          <div>
            <h2 className="text-3xl font-bold text-primary md:text-4xl">Built for Pakistani students and families</h2>
            <p className="mt-4 text-muted-foreground">From matric marks to MDCAT scores, UniOne understands the local admissions system — so you can focus on choosing the right future.</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {benefits.map((b) => (
              <div key={b.title} className="rounded-2xl bg-card p-5 shadow-card">
                <b.icon className="h-6 w-6 text-warm" />
                <h3 className="mt-3 font-bold">{b.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{b.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container-page py-20">
        <div className="flex items-end justify-between gap-4">
          <h2 className="text-3xl font-bold text-primary md:text-4xl">Featured universities</h2>
          <Link to="/universities" className="text-sm font-bold text-primary hover:underline">View all →</Link>
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((u) => <UniversityCard key={u.slug} u={u} />)}
        </div>
      </section>

      <section className="bg-ink py-20 text-ink-foreground">
        <div className="container-page">
          <h2 className="text-center text-3xl font-bold md:text-4xl">Students love the simplicity</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {testimonials.map((t) => (
              <figure key={t.name} className="rounded-2xl border border-ink-foreground/10 p-6">
                <Quote className="h-6 w-6 text-warm" />
                <blockquote className="mt-3 opacity-90">{t.text}</blockquote>
                <figcaption className="mt-4 text-sm font-bold">{t.name} <span className="font-normal opacity-60">· {t.city}</span></figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className="container-page max-w-3xl py-20">
        <h2 className="text-center text-3xl font-bold text-primary md:text-4xl">Frequently asked questions</h2>
        <div className="mt-10 space-y-3">
          {faqs.map((f) => (
            <details key={f.q} className="group rounded-2xl border bg-card p-5 shadow-card">
              <summary className="cursor-pointer list-none font-bold marker:hidden">{f.q}<span className="float-right text-warm group-open:rotate-45 transition">+</span></summary>
              <p className="mt-3 text-sm text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
}
