import { Link } from "@tanstack/react-router";
import { Heart, MapPin, CalendarClock, Award } from "lucide-react";
import { type University, formatDate, formatPKR, minFee, nextDeadline } from "@/lib/data/universities";
import { useShortlist } from "@/lib/shortlist";

export function UniversityCard({ u }: { u: University }) {
  const { has, toggle } = useShortlist();
  const saved = has(u.slug);
  return (
    <article className="group relative flex flex-col rounded-2xl border bg-card p-5 shadow-card transition hover:-translate-y-0.5">
      <div className="flex items-start justify-between gap-3">
        <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-secondary font-display text-sm font-bold text-primary">
          {u.short.slice(0, 4)}
        </div>
        <button
          onClick={() => toggle(u.slug)}
          aria-label={saved ? "Remove from shortlist" : "Add to shortlist"}
          aria-pressed={saved}
          className={`rounded-full border p-2 transition ${saved ? "border-warm bg-warm-soft text-warm" : "text-muted-foreground hover:text-warm"}`}
        >
          <Heart className="h-4 w-4" fill={saved ? "currentColor" : "none"} />
        </button>
      </div>
      <Link to="/universities/$slug" params={{ slug: u.slug }} className="mt-4">
        <h3 className="text-lg font-bold leading-snug group-hover:text-primary">{u.name}</h3>
      </Link>
      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
        <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{u.city}</span>
        <span>{u.type}</span>
        {u.scholarships && <span className="inline-flex items-center gap-1 text-success"><Award className="h-3.5 w-3.5" />Scholarships</span>}
      </div>
      <div className="mt-auto flex items-end justify-between border-t pt-4 mt-5 text-sm">
        <div>
          <div className="text-xs text-muted-foreground">Application fee from</div>
          <div className="font-bold text-primary">{formatPKR(minFee(u))}</div>
        </div>
        <div className="text-right">
          <div className="text-xs text-muted-foreground">Next deadline</div>
          <div className="inline-flex items-center gap-1 font-semibold"><CalendarClock className="h-3.5 w-3.5 text-warm" />{formatDate(nextDeadline(u))}</div>
        </div>
      </div>
    </article>
  );
}
