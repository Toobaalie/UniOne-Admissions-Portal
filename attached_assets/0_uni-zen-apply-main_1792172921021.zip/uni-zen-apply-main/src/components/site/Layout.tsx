import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { GraduationCap, Menu, X, Heart } from "lucide-react";
import { useShortlist } from "@/lib/shortlist";

const nav = [
  { to: "/universities", label: "Universities" },
  { to: "/compare", label: "Compare" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold text-primary">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground">
        <GraduationCap className="h-5 w-5" />
      </span>
      Uni<span className="text-warm">One</span>
    </Link>
  );
}

export function Header() {
  const [open, setOpen] = useState(false);
  const { items } = useShortlist();
  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="container-page flex h-16 items-center justify-between">
        <Logo />
        <nav className="hidden items-center gap-7 md:flex" aria-label="Main">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="text-sm font-semibold text-muted-foreground hover:text-primary" activeProps={{ className: "text-primary" }}>
              {n.label}
              {n.to === "/compare" && items.length > 0 && (
                <span className="ml-1 rounded-full bg-warm px-1.5 text-xs text-warm-foreground">{items.length}</span>
              )}
            </Link>
          ))}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <Link to="/universities" className="btn btn-primary">Start applying</Link>
        </div>
        <button className="md:hidden" aria-label="Toggle menu" onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav className="border-t bg-background md:hidden">
          <div className="container-page flex flex-col py-3">
            {nav.map((n) => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="py-3 font-semibold">
                {n.label}
              </Link>
            ))}
            <Link to="/universities" onClick={() => setOpen(false)} className="btn btn-primary mt-2">Start applying</Link>
          </div>
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-24 bg-ink text-ink-foreground">
      <div className="container-page grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="font-display text-2xl font-bold">Uni<span className="text-warm">One</span></div>
          <p className="mt-3 max-w-sm text-sm opacity-75">One profile. Many universities. A single checkout. Pakistan's centralized admission portal.</p>
        </div>
        <div className="space-y-2 text-sm">
          <div className="font-bold">Explore</div>
          <Link to="/universities" className="block opacity-75 hover:opacity-100">Universities</Link>
          <Link to="/compare" className="block opacity-75 hover:opacity-100"><Heart className="mr-1 inline h-3 w-3" />Shortlist & compare</Link>
          <Link to="/about" className="block opacity-75 hover:opacity-100">About</Link>
        </div>
        <div className="space-y-2 text-sm">
          <div className="font-bold">Help</div>
          <Link to="/contact" className="block opacity-75 hover:opacity-100">Contact</Link>
          <Link to="/privacy" className="block opacity-75 hover:opacity-100">Privacy Policy</Link>
          <Link to="/terms" className="block opacity-75 hover:opacity-100">Terms of Use</Link>
        </div>
      </div>
      <div className="border-t border-ink-foreground/10 py-5 text-center text-xs opacity-60">© {new Date().getFullYear()} UniOne. All rights reserved.</div>
    </footer>
  );
}

export function PageHeader({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: React.ReactNode }) {
  return (
    <section className="border-b bg-secondary/60">
      <div className="container-page py-12 md:py-16">
        {eyebrow && <div className="text-sm font-bold uppercase tracking-wider text-warm">{eyebrow}</div>}
        <h1 className="mt-2 text-3xl font-bold text-primary md:text-5xl">{title}</h1>
        {children && <div className="mt-4 max-w-2xl text-muted-foreground">{children}</div>}
      </div>
    </section>
  );
}
